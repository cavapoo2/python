import asyncio
from playwright.async_api import async_playwright


async def diagnose_trac_page(url: str):
    """
    Diagnostic script to inspect Trac page structure and find correct selectors.
    """
    async with async_playwright() as p:
        browser = await p.chromium.launch(
            headless=False,
            args=['--disable-blink-features=AutomationControlled']
        )
        
        context = await browser.new_context(
            viewport={'width': 1920, 'height': 1080},
            user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36'
        )
        
        page = await context.new_page()
        page.set_default_timeout(60000)
        
        print(f"Loading: {url}")
        await page.goto(url, wait_until="domcontentloaded", timeout=60000)
        await page.wait_for_timeout(3000)
        
        print("\n" + "="*80)
        print("DIAGNOSTIC REPORT")
        print("="*80)
        
        # Check Trac version
        print("\n1. Checking Trac Version:")
        try:
            footer = await page.locator("#footer").text_content()
            if footer:
                print(f"   Footer text: {footer.strip()}")
        except:
            print("   Could not find footer")
        
        # Check main ticket container
        print("\n2. Checking Main Ticket Container:")
        selectors_to_check = ["#ticket", "#content", ".ticket", "div[id='ticket']"]
        for selector in selectors_to_check:
            count = await page.locator(selector).count()
            print(f"   {selector}: {count} element(s)")
        
        # Check properties/fields table
        print("\n3. Checking Properties/Fields:")
        property_selectors = [
            "#properties",
            "#properties table",
            "#properties table.properties",
            ".properties",
            "table.properties"
        ]
        for selector in property_selectors:
            count = await page.locator(selector).count()
            print(f"   {selector}: {count} element(s)")
        
        # Check description
        print("\n4. Checking Description Area:")
        description_selectors = [
            "#ticket .description",
            ".description",
            "#ticket .description .searchable",
            ".description .searchable",
            "#description",
            "div.description"
        ]
        for selector in description_selectors:
            count = await page.locator(selector).count()
            if count > 0:
                try:
                    text = await page.locator(selector).first.text_content()
                    preview = text[:100] if text else "empty"
                    print(f"   {selector}: {count} element(s) - Preview: {preview}...")
                except:
                    print(f"   {selector}: {count} element(s) - Could not get text")
        
        # Check changelog/comments
        print("\n5. Checking Changelog/Comments:")
        changelog_selectors = [
            "#changelog",
            "#changelog .change",
            ".change",
            "#changelog div.change",
            "div.change",
            "#changelog h3",
            "div[id='changelog']"
        ]
        for selector in changelog_selectors:
            count = await page.locator(selector).count()
            print(f"   {selector}: {count} element(s)")
        
        # If changelog exists, check its children
        changelog_count = await page.locator("#changelog").count()
        if changelog_count > 0:
            print("\n   Changelog HTML Structure:")
            try:
                # Get direct children
                children = await page.locator("#changelog > *").all()
                print(f"   Direct children count: {len(children)}")
                for i, child in enumerate(children[:5]):  # First 5 only
                    tag = await child.evaluate("el => el.tagName")
                    classes = await child.get_attribute("class")
                    print(f"     Child {i}: <{tag.lower()} class='{classes}'>")
            except Exception as e:
                print(f"   Error inspecting children: {e}")
        
        # Check attachments
        print("\n6. Checking Attachments:")
        attachment_selectors = [
            "#attachments",
            "#attachments dt",
            "#attachments dt a",
            "dl#attachments",
            ".attachments"
        ]
        for selector in attachment_selectors:
            count = await page.locator(selector).count()
            print(f"   {selector}: {count} element(s)")
        
        # Save full HTML for inspection
        print("\n7. Saving Page HTML:")
        html = await page.content()
        with open("trac_page_debug.html", "w", encoding="utf-8") as f:
            f.write(html)
        print("   Saved to: trac_page_debug.html")
        
        # Take screenshot
        print("\n8. Taking Screenshot:")
        await page.screenshot(path="trac_page_debug.png", full_page=True)
        print("   Saved to: trac_page_debug.png")
        
        # Try to extract any comment-like structure
        print("\n9. Looking for Comment Patterns:")
        patterns = [
            ("h3.change", "Change headers"),
            ("div.comment", "Comment divs"),
            (".trac-field-author", "Author fields"),
            (".trac-field-time", "Time fields"),
            ("a.timeline", "Timeline links"),
            (".changes", "Changes class"),
            ("div[class*='change']", "Divs with 'change' in class")
        ]
        for selector, description in patterns:
            count = await page.locator(selector).count()
            if count > 0:
                print(f"   {description} ({selector}): {count} element(s)")
        
        print("\n" + "="*80)
        print("DIAGNOSIS COMPLETE")
        print("="*80)
        print("\nReview the saved files:")
        print("  - trac_page_debug.html (full page source)")
        print("  - trac_page_debug.png (screenshot)")
        print("\nPress Enter to close browser...")
        
        input()
        await browser.close()


async def main():
    # Replace with your Trac ticket URL
    ticket_url = input("Enter Trac ticket URL: ").strip()
    if not ticket_url:
        ticket_url = "https://trac.ffmpeg.org/ticket/10735"
        print(f"Using default: {ticket_url}")
    
    await diagnose_trac_page(ticket_url)


if __name__ == "__main__":
    asyncio.run(main())
