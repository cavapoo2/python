# Trac Ticket Scraper

A Python script using Playwright to scrape Trac ticket information and save it to JSON with attachments.

## Features

- Extracts all ticket fields (reported by, priority, component, version, etc.)
- Captures the ticket summary and description
- Extracts all comments with author and timestamp
- Downloads all attachments in their original format
- Saves everything to a structured JSON file

## Installation

1. Install the required Python packages:
```bash
pip install -r requirements.txt
```

2. Install Playwright browsers:
```bash
playwright install chromium
```

## Usage

### Basic Usage

Run the script with the default ticket URL:
```bash
python trac_ticket_scraper.py
```

### Custom Usage

Modify the script to scrape any Trac ticket:

```python
import asyncio
from trac_ticket_scraper import scrape_trac_ticket

async def main():
    ticket_data = await scrape_trac_ticket(
        url="https://trac.ffmpeg.org/ticket/YOUR_TICKET_NUMBER",
        output_dir="my_output_folder"
    )
    print(ticket_data)

asyncio.run(main())
```

## Output Structure

The script creates the following structure:

```
ticket_data/
├── ticket_XXXXX.json          # Main JSON file with all ticket data
└── attachments/                # Directory containing all downloaded attachments
    ├── attachment1.txt
    ├── attachment2.png
    └── ...
```

## JSON Structure

The output JSON file contains:

```json
{
  "url": "https://trac.ffmpeg.org/ticket/10735",
  "ticket_number": "10735",
  "scraped_at": "2024-02-05T...",
  "fields": {
    "reported by": "...",
    "priority": "...",
    "component": "...",
    "version": "...",
    "status": "...",
    "summary": "..."
  },
  "description": "Full ticket description...",
  "comments": [
    {
      "comment_number": 1,
      "author": "...",
      "timestamp": "...",
      "text": "Comment text..."
    }
  ],
  "attachments": [
    {
      "filename": "example.txt",
      "url": "https://...",
      "local_path": "attachments/example.txt"
    }
  ]
}
```

## Error Handling

- If an attachment fails to download, the error is logged in the JSON file
- If certain fields are missing, the script continues and extracts what's available
- All errors are printed to console for debugging

## Requirements

- Python 3.7+
- playwright
- Internet connection to access Trac tickets

## Notes

- The script runs in headless mode by default (no browser window visible)
- Attachments are saved in their original format
- The script respects the Trac site structure as of February 2024
