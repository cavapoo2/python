import asyncio
import json
import os
from pathlib import Path
from playwright.async_api import async_playwright
from datetime import datetime
import re


async def scrape_trac_ticket(url: str, output_dir: str = "ticket_data"):
    """
    Scrape a Trac ticket and save all information to JSON with attachments.
    
    Args:
        url: URL of the Trac ticket
        output_dir: Directory to save output files
    """
    # Create output directory structure
    output_path = Path(output_dir)
    output_path.mkdir(exist_ok=True)
    
    attachments_dir = output_path / "attachments"
    attachments_dir.mkdir(exist_ok=True)
    
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page()
        
        print(f"Loading ticket: {url}")
        await page.goto(url, wait_until="networkidle")
        
        # Extract ticket number from URL
        ticket_match = re.search(r'/ticket/(\d+)', url)
        ticket_number = ticket_match.group(1) if ticket_match else "unknown"
        
        ticket_data = {
            "url": url,
            "ticket_number": ticket_number,
            "scraped_at": datetime.now().isoformat(),
            "fields": {},
            "description": "",
            "comments": [],
            "attachments": []
        }
        
        # Extract ticket fields from the property table
        print("Extracting ticket fields...")
        try:
            # Get all rows from the properties table
            property_rows = await page.locator("#properties table.properties tr").all()
            
            for row in property_rows:
                # Get the header (field name)
                header = await row.locator("th").text_content()
                if header:
                    header = header.strip().rstrip(':').lower()
                    
                    # Get the value
                    value_elem = row.locator("td")
                    value = await value_elem.text_content()
                    
                    if value:
                        ticket_data["fields"][header] = value.strip()
        except Exception as e:
            print(f"Error extracting fields: {e}")
        
        # Extract summary (title)
        try:
            summary = await page.locator("#ticket h1.summary").text_content()
            if summary:
                ticket_data["fields"]["summary"] = summary.strip()
        except Exception as e:
            print(f"Error extracting summary: {e}")
        
        # Extract description
        print("Extracting description...")
        try:
            description_elem = page.locator("#ticket .description .searchable")
            description = await description_elem.text_content()
            if description:
                ticket_data["description"] = description.strip()
        except Exception as e:
            print(f"Error extracting description: {e}")
        
        # Extract comments
        print("Extracting comments...")
        try:
            comments = await page.locator("#changelog .change").all()
            
            for idx, comment in enumerate(comments):
                comment_data = {
                    "comment_number": idx + 1,
                    "author": "",
                    "timestamp": "",
                    "text": ""
                }
                
                # Get comment header info (author and timestamp)
                try:
                    header = await comment.locator(".trac-field-author").text_content()
                    if header:
                        comment_data["author"] = header.strip()
                except:
                    pass
                
                try:
                    timestamp = await comment.locator(".trac-field-time").text_content()
                    if timestamp:
                        comment_data["timestamp"] = timestamp.strip()
                except:
                    pass
                
                # Get comment text
                try:
                    text_elem = comment.locator(".comment.searchable")
                    text = await text_elem.text_content()
                    if text:
                        comment_data["text"] = text.strip()
                except:
                    pass
                
                # Only add if there's actual comment text
                if comment_data["text"] or comment_data["author"]:
                    ticket_data["comments"].append(comment_data)
        except Exception as e:
            print(f"Error extracting comments: {e}")
        
        # Extract and download attachments
        print("Extracting attachments...")
        try:
            attachments = await page.locator("#attachments dt a").all()
            
            for attachment in attachments:
                filename = await attachment.text_content()
                href = await attachment.get_attribute("href")
                
                if filename and href:
                    filename = filename.strip()
                    
                    # Construct full URL if href is relative
                    if href.startswith('/'):
                        base_url = '/'.join(url.split('/')[:3])
                        attachment_url = base_url + href
                    else:
                        attachment_url = href
                    
                    print(f"  Downloading: {filename}")
                    
                    # Download the attachment
                    try:
                        # Create a new page for download to avoid navigation issues
                        download_page = await browser.new_page()
                        
                        # Start waiting for download
                        async with download_page.expect_download() as download_info:
                            await download_page.goto(attachment_url)
                        
                        download = await download_info.value
                        
                        # Save the file
                        save_path = attachments_dir / filename
                        await download.save_as(str(save_path))
                        
                        await download_page.close()
                        
                        ticket_data["attachments"].append({
                            "filename": filename,
                            "url": attachment_url,
                            "local_path": str(save_path.relative_to(output_path))
                        })
                        print(f"    Saved to: {save_path}")
                    except Exception as e:
                        print(f"    Error downloading {filename}: {e}")
                        ticket_data["attachments"].append({
                            "filename": filename,
                            "url": attachment_url,
                            "error": str(e)
                        })
        except Exception as e:
            print(f"Error extracting attachments: {e}")
        
        await browser.close()
        
        # Save ticket data to JSON
        json_path = output_path / f"ticket_{ticket_number}.json"
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(ticket_data, f, indent=2, ensure_ascii=False)
        
        print(f"\n✓ Ticket data saved to: {json_path}")
        print(f"✓ Total fields extracted: {len(ticket_data['fields'])}")
        print(f"✓ Total comments extracted: {len(ticket_data['comments'])}")
        print(f"✓ Total attachments: {len(ticket_data['attachments'])}")
        
        return ticket_data


async def main():
    # Example usage
    ticket_url = "https://trac.ffmpeg.org/ticket/10735"
    
    print("=" * 60)
    print("Trac Ticket Scraper")
    print("=" * 60)
    print()
    
    ticket_data = await scrape_trac_ticket(ticket_url)
    
    print("\n" + "=" * 60)
    print("Extraction Complete!")
    print("=" * 60)
    print("\nTicket Summary:")
    print(f"  Number: {ticket_data['ticket_number']}")
    if 'summary' in ticket_data['fields']:
        print(f"  Summary: {ticket_data['fields']['summary']}")
    print(f"\nKey Fields:")
    for key in ['reported by', 'priority', 'component', 'version', 'status', 'resolution']:
        if key in ticket_data['fields']:
            print(f"  {key.title()}: {ticket_data['fields'][key]}")


if __name__ == "__main__":
    asyncio.run(main())
